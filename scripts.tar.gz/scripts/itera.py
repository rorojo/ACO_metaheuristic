

import os
import subprocess


for i in xrange(400):  
    
    proc = subprocess.Popen(["./antRank"])
    proc.wait()


